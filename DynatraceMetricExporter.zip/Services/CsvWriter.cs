using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using DynatraceMetricExporter.Models;

namespace DynatraceMetricExporter.Services
{
    public class CsvWriter
    {
        public async Task WriteAsync(string file, List<MetricRecord> data)
        {
            using (var sw = new StreamWriter(file))
            {
                await sw.WriteLineAsync("HostId,HostName,Timestamp,Value");

                foreach (var d in data)
                {
                    await sw.WriteLineAsync($"{d.HostId},{d.HostName},{d.Timestamp},{d.Value}");
                }
            }
        }
    }
}
