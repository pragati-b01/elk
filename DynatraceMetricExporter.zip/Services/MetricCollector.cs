using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DynatraceMetricExporter.Models;

namespace DynatraceMetricExporter.Services
{
    public class MetricCollector
    {
        private readonly DynatraceClient _client;

        public MetricCollector(DynatraceClient client)
        {
            _client = client;
        }

        public async Task<List<MetricRecord>> CollectAsync(List<string> hosts, string metricType)
        {
            var tasks = hosts.Select(async h =>
            {
                var response = await _client.GetMetricAsync(h, metricType);
                return response;
            });

            var results = await Task.WhenAll(tasks);
            return results.SelectMany(x => x).ToList();
        }
    }
}
