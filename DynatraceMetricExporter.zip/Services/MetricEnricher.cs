using System.Collections.Generic;
using System.Linq;
using DynatraceMetricExporter.Models;

namespace DynatraceMetricExporter.Services
{
    public class MetricEnricher
    {
        public List<MetricRecord> Enrich(List<MetricRecord> data, Dictionary<string, string> lookup)
        {
            foreach (var d in data)
            {
                if (lookup.TryGetValue(d.HostId, out var name))
                {
                    d.HostName = name;
                }
                else
                {
                    d.HostName = "UNKNOWN";
                }
            }
            return data;
        }
    }
}
