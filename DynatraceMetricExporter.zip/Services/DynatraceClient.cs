using System.Collections.Generic;
using System.Threading.Tasks;
using DynatraceMetricExporter.Models;

namespace DynatraceMetricExporter.Services
{
    public class DynatraceClient
    {
        public async Task<List<MetricRecord>> GetMetricAsync(string hostId, string metricType)
        {
            await Task.Delay(50); // simulate API call

            return new List<MetricRecord>
            {
                new MetricRecord
                {
                    HostId = hostId,
                    Value = 10.5
                }
            };
        }

        public async Task<List<HostMetadata>> GetHostMetadataAsync()
        {
            await Task.Delay(50);

            return new List<HostMetadata>
            {
                new HostMetadata { HostId = "1", HostName = "Host-A" },
                new HostMetadata { HostId = "2", HostName = "Host-B" }
            };
        }
    }
}
