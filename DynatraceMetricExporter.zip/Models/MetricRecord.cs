using System;

namespace DynatraceMetricExporter.Models
{
    public class MetricRecord
    {
        public string HostId { get; set; }
        public string HostName { get; set; }
        public DateTime Timestamp { get; set; }
        public double Value { get; set; }
    }
}
