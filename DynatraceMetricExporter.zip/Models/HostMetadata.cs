namespace DynatraceMetricExporter.Models
{
    public class HostMetadata
    {
        public string HostId { get; set; }
        public string HostName { get; set; }
    }
}
