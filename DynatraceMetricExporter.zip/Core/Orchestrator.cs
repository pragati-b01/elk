using System.Collections.Generic;
using System.Threading.Tasks;
using DynatraceMetricExporter.Models;

namespace DynatraceMetricExporter.Core
{
    public class Orchestrator
    {
        private readonly Services.MetricCollector _collector;
        private readonly Services.DynatraceClient _client;
        private readonly Services.MetricEnricher _enricher;
        private readonly Services.CsvWriter _writer;

        public Orchestrator()
        {
            _client = new Services.DynatraceClient();
            _collector = new Services.MetricCollector(_client);
            _enricher = new Services.MetricEnricher();
            _writer = new Services.CsvWriter();
        }

        public async Task ExecuteAsync(List<string> hosts)
        {
            var lookupList = await _client.GetHostMetadataAsync();
            var lookup = new Dictionary<string, string>();

            foreach (var h in lookupList)
                lookup[h.HostId] = h.HostName;

            var cpuTask = _collector.CollectAsync(hosts, "CPU");
            var memTask = _collector.CollectAsync(hosts, "Memory");
            var diskTask = _collector.CollectAsync(hosts, "Disk");

            await Task.WhenAll(cpuTask, memTask, diskTask);

            var cpu = _enricher.Enrich(cpuTask.Result, lookup);
            var mem = _enricher.Enrich(memTask.Result, lookup);
            var disk = _enricher.Enrich(diskTask.Result, lookup);

            await _writer.WriteAsync("cpu_metrics.csv", cpu);
            await _writer.WriteAsync("memory_metrics.csv", mem);
            await _writer.WriteAsync("disk_metrics.csv", disk);
        }
    }
}
