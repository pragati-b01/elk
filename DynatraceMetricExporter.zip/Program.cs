using System;
using System.Collections.Generic;
using DynatraceMetricExporter.Core;

namespace DynatraceMetricExporter
{
    class Program
    {
        static async System.Threading.Tasks.Task Main(string[] args)
        {
            var hosts = new List<string> { "1", "2" };

            var orch = new Orchestrator();
            await orch.ExecuteAsync(hosts);

            Console.WriteLine("Export completed");
        }
    }
}
