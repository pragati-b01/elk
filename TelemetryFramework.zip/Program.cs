using System;
using System.Threading.Tasks;
using TelemetryFramework.Config;
using TelemetryFramework.Services;

class Program
{
    static async Task Main(string[] args)
    {
        var config = ConfigLoader.Load("config.json");

        var client = new DynatraceClient(config.BaseUrl, config.Token);

        var orchestrator = new TelemetryOrchestrator(client, config);

        var data = await orchestrator.RunAsync();

        CsvExporter.Export(config.Output.CsvPath, data);

        Console.WriteLine($"Completed. Records: {data.Count}");
    }
}
