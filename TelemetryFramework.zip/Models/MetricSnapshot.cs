using System;

namespace TelemetryFramework.Models
{
    public class MetricSnapshot
    {
        public string HostId { get; set; }
        public string HostName { get; set; }
        public DateTime Timestamp { get; set; }

        public double CpuUsage { get; set; }
        public double MemoryUsed { get; set; }
        public double MemoryTotal { get; set; }
        public double DiskUsed { get; set; }
        public double DiskAvailable { get; set; }
        public double DiskTotal { get; set; }
    }
}
