using Newtonsoft.Json;
using System.IO;

namespace TelemetryFramework.Config
{
    public static class ConfigLoader
    {
        public static Config Load(string path)
        {
            var json = File.ReadAllText(path);
            return JsonConvert.DeserializeObject<Config>(json);
        }
    }
}
