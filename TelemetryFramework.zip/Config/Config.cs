namespace TelemetryFramework.Config
{
    public class Config
    {
        public string BaseUrl { get; set; }
        public string Token { get; set; }
        public string[] Hosts { get; set; }
        public MetricConfig Metrics { get; set; }
        public OutputConfig Output { get; set; }
        public TimeRangeConfig TimeRange { get; set; }
        public string Resolution { get; set; }
    }

    public class MetricConfig
    {
        public string Cpu { get; set; }
        public string MemoryUsed { get; set; }
        public string MemoryTotal { get; set; }
        public string DiskUsed { get; set; }
        public string DiskAvailable { get; set; }
    }

    public class OutputConfig
    {
        public string CsvPath { get; set; }
    }

    public class TimeRangeConfig
    {
        public string From { get; set; }
        public string To { get; set; }
    }
}
