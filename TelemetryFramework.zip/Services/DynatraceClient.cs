using Newtonsoft.Json.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace TelemetryFramework.Services
{
    public class DynatraceClient
    {
        private readonly string _baseUrl;
        private readonly string _token;

        public DynatraceClient(string baseUrl, string token)
        {
            _baseUrl = baseUrl;
            _token = token;
        }

        public async Task<JObject> GetMetricAsync(string metric, string host, string from, string to, string resolution)
        {
            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", $"Api-Token {_token}");

                var url = $"{_baseUrl}/api/v2/metrics/query?metricSelector={metric}&entitySelector=type(HOST),entityId({host})&from={from}&to={to}&resolution={resolution}";

                var res = await client.GetStringAsync(url);
                return JObject.Parse(res);
            }
        }
    }
}
