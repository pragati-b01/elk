using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TelemetryFramework.Config;
using TelemetryFramework.Models;

namespace TelemetryFramework.Services
{
    public class TelemetryOrchestrator
    {
        private readonly DynatraceClient _client;
        private readonly Config.Config _config;

        public TelemetryOrchestrator(DynatraceClient client, Config.Config config)
        {
            _client = client;
            _config = config;
        }

        public async Task<List<MetricSnapshot>> RunAsync()
        {
            var tasks = _config.Hosts.Select(async host =>
            {
                var cpu = await _client.GetMetricAsync(_config.Metrics.Cpu, host, _config.TimeRange.From, _config.TimeRange.To, _config.Resolution);

                return new MetricSnapshot
                {
                    HostId = host,
                    HostName = host,
                    CpuUsage = 0
                };
            });

            return (await Task.WhenAll(tasks)).ToList();
        }
    }
}
