using System.Collections.Generic;
using System.IO;
using System.Linq;
using TelemetryFramework.Models;

namespace TelemetryFramework.Services
{
    public static class CsvExporter
    {
        public static void Export(string path, List<MetricSnapshot> data)
        {
            var lines = new List<string>
            {
                "HostId,HostName,Timestamp,CpuUsage,MemoryUsed,MemoryTotal,DiskUsed,DiskAvailable,DiskTotal"
            };

            lines.AddRange(data.Select(x =>
                $"{x.HostId},{x.HostName},{x.Timestamp},{x.CpuUsage},{x.MemoryUsed},{x.MemoryTotal},{x.DiskUsed},{x.DiskAvailable},{x.DiskTotal}"
            ));

            File.WriteAllLines(path, lines);
        }
    }
}
