# Unified Utility (Console App)

## Run examples:
MyUtility.exe --task HealthCheck
MyUtility.exe --bodyFile "C:\Reports\health.html"

## Requirements:
- .NET 6+
- Install NuGet packages:
  - MailKit
  - Microsoft.Extensions.Configuration.Json
  - Microsoft.Extensions.Configuration.CommandLine
