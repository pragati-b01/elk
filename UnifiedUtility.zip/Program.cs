using Microsoft.Extensions.Configuration;

class Program
{
    static void Main(string[] args)
    {
        try
        {
            var config = BuildConfig(args);
            var appConfig = config.Get<AppConfig>();

            string taskName = config["task"];
            string scriptOverride = config["script"];
            string bodyFile = config["bodyFile"];
            string subjectOverride = config["subject"];
            string toOverride = config["to"];

            TaskConfig task = null;

            if (!string.IsNullOrEmpty(taskName))
            {
                if (!appConfig.Tasks.ContainsKey(taskName))
                    throw new Exception($"Task '{taskName}' not found in config.");

                task = appConfig.Tasks[taskName];
            }

            string scriptPath = scriptOverride ?? task?.Script;
            string subject = subjectOverride ?? task?.DefaultSubject ?? "Report";
            string to = toOverride ?? task?.To;

            if (string.IsNullOrEmpty(bodyFile))
            {
                if (string.IsNullOrEmpty(scriptPath))
                    throw new Exception("No script or bodyFile provided.");

                Console.WriteLine("Executing script...");
                bodyFile = ScriptExecutor.Execute(scriptPath);
            }

            if (!File.Exists(bodyFile))
                throw new Exception($"HTML file not found: {bodyFile}");

            Console.WriteLine($"Reading HTML from: {bodyFile}");
            string html = File.ReadAllText(bodyFile);

            Console.WriteLine("Sending email...");
            EmailService.SendEmail(
                appConfig.Smtp.Server,
                appConfig.Smtp.Port,
                appConfig.Smtp.From,
                to,
                subject,
                html
            );

            Console.WriteLine("Email sent successfully.");
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR: " + ex.Message);
        }
    }

    static IConfiguration BuildConfig(string[] args)
    {
        return new ConfigurationBuilder()
            .AddJsonFile("appsettings.json", optional: false)
            .AddCommandLine(args)
            .Build();
    }
}
