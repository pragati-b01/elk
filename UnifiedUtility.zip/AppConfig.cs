public class AppConfig
{
    public SmtpConfig Smtp { get; set; }
    public Dictionary<string, TaskConfig> Tasks { get; set; }
}

public class SmtpConfig
{
    public string Server { get; set; }
    public int Port { get; set; }
    public string From { get; set; }
}
