public class TaskConfig
{
    public string Script { get; set; }
    public string OutputFolder { get; set; }
    public string DefaultSubject { get; set; }
    public string To { get; set; }
}
