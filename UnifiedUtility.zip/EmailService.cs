using MailKit.Net.Smtp;
using MimeKit;

public class EmailService
{
    public static void SendEmail(string smtpServer, int port, string from, string to, string subject, string htmlBody)
    {
        var message = new MimeMessage();
        message.From.Add(MailboxAddress.Parse(from));
        message.To.Add(MailboxAddress.Parse(to));
        message.Subject = subject;

        message.Body = new TextPart("html")
        {
            Text = htmlBody
        };

        using var client = new SmtpClient();
        client.Connect(smtpServer, port, false);
        client.Send(message);
        client.Disconnect(true);
    }
}
